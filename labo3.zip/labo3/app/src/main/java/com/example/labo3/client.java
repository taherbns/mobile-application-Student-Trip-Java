package com.example.labo3;

import java.util.Calendar;

public class client {
    private String nom;
    private String prenom;
    private String dateDepart;
    private String dateArrivee;
    private int nombrePersonnes;


    public client(String nom, String prenom, String dateDepart, String dateArrivee, int nombrePersonnes) {
        this.nom = nom;
        this.prenom = prenom;
        this.dateDepart = dateDepart;
        this.dateArrivee = dateArrivee;
        this.nombrePersonnes = nombrePersonnes;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getDateDepart() {
        return dateDepart;
    }

    public void setDateDepart(String dateDepart) {
        this.dateDepart = dateDepart;
    }

    public String getDateArrivee() {
        return dateArrivee;
    }

    public void setDateArrivee(String dateArrivee) {
        this.dateArrivee = dateArrivee;
    }

    public int getNombrePersonnes() {
        return nombrePersonnes;
    }

    public void setNombrePersonnes(int nombrePersonnes) {
        this.nombrePersonnes = nombrePersonnes;
    }



    public double calculerMontantTotal() {
        double montantTotal = 0.0;

        double montantActiviteEquitation = DatabaseGateway.getFraisEquitation()  + DatabaseGateway.calculerMontantEquitation;
        double montantActiviteCanot = DatabaseGateway.getFraisCanot()  + DatabaseGateway.calculerMontantCanot;
        double montantActiviteEscalade = DatabaseGateway.getFraisEscalade() + DatabaseGateway.calculerMontantEscalade;

        montantTotal = montantActiviteEquitation + montantActiviteCanot + montantActiviteEscalade;

        return montantTotal;
    }


}
