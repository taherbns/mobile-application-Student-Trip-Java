package com.example.labo3;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.Calendar;

public class DataBaseGateway extends SQLiteOpenHelper {
    private SQLiteDatabase db ;

    public DataBaseGateway (@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String myQuery = "create table if not exists MyCamping(id integer primary key autoincrement,nom text , prenom text , dateDepart text , dateArrival text , nbPersonne integer , facture integer);";
        sqLiteDatabase.execSQL(myQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists MyCamping;");
        onCreate(sqLiteDatabase);
    }
    public void openDB()
    {
        this.db = getWritableDatabase();
    }

    public void CloseDB()
    {
        this.db.close();
    }
    public void AddClient(String nom, String prenom, Calendar dateDepart, Calendar dateArrival, int nbPersonne, int facture) {
        ContentValues cv = new ContentValues();
        cv.put("nom", nom);
        cv.put("prenom", prenom);
        cv.put("dateDepart", formatDate(dateDepart));
        cv.put("dateArrival", formatDate(dateArrival));
        cv.put("nbPersonne", nbPersonne);
        cv.put("facture", facture);

        this.db.insert("MyCamping", null, cv);
    }


    private String formatDate(Calendar calendar) {

        return calendar.get(Calendar.YEAR) + "-" +
                (calendar.get(Calendar.MONTH) + 1) + "-" +
                calendar.get(Calendar.DAY_OF_MONTH);
    }

}