package com.example.labo3;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Calendar;

public class Acceuil extends AppCompatActivity {
    private EditText FirstName;
    private EditText LastName;
    private Button buttonMin;
    private EditText NumPeople;
    private Button buttonPlus;
    private Button ArrivalDate;
    private Button DepartureDate;
    private Button reserveButton;

    private int c ;

    private DataBaseGateway gateWay ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.gateWay = new DataBaseGateway(this,"MyCamping",null,1);
        this.gateWay.openDB();

        FirstName = findViewById(R.id.editTextFirstName);
        LastName = findViewById(R.id.editTextLastName);
        buttonMin = findViewById(R.id.buttonMinus);
        NumPeople = findViewById(R.id.editTextNumPeople);
        buttonPlus = findViewById(R.id.buttonPlus);
        ArrivalDate = findViewById(R.id.editTextArrivalDate);
        DepartureDate = findViewById(R.id.editTextDepartureDate);
        reserveButton = findViewById(R.id.reserveButton);

        buttonPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c++;
                NumPeople.setText(String.valueOf(c));
            }
        });

        buttonMin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c > 0) {
                    c--;
                    NumPeople.setText(String.valueOf(c));
                }
            }
        });
        ArrivalDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(Acceuil.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        String date = dayOfMonth + "/" + (month + 1) + "/" + year;ArrivalDate.setText(date);}
                    }, year, month, day) ;
                datePickerDialog.show();
            }
        });


        DepartureDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(Acceuil.this,new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        String date = dayOfMonth + "/" + (month + 1) + "/" + year;DepartureDate.setText(date);}
                }, year, month, day);
                datePickerDialog.show();
            }
        });

        reserveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Acceuil.this, reserved.class);
                startActivity(intent);
            }
        });

        this.gateWay.CloseDB();
    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem equitation = menu.add(Menu.NONE, Menu.FIRST, 0, "equitation");
        MenuItem canot = menu.add(Menu.NONE, Menu.FIRST + 1, 1, "canot");
        MenuItem escalade = menu.add(Menu.NONE, Menu.FIRST + 2, 3, "escalade");
        MenuItem facture = menu.add(Menu.NONE, Menu.FIRST + 3, 4, "facture");
        MenuItem quitter = menu.add(Menu.NONE, Menu.FIRST + 4, 5, "quitter");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case Menu.FIRST:
                Intent equitationIntent = new Intent(this, equitation.class);
                startActivity(equitationIntent);
                    return true;
                    case Menu.FIRST+1:
                    Intent canotIntent = new Intent(this, canot.class);
                    startActivity(canotIntent);
                    return true;
                 case Menu.FIRST+2:
                     Intent escaladeIntent = new Intent(this, escalade.class);
                     startActivity(escaladeIntent);
                    return true;
                case Menu.FIRST+3:
                    Intent factureIntent = new Intent(this, Facture.class);
                    startActivity(factureIntent);
                    return true;
                    case Menu.FIRST+4:
                        DialogQuitter();
                        return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void DialogQuitter() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Quitter");
        builder.setMessage("Êtes-vous sûr de vouloir quitter ?");

        builder.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                finish();
            }
        });

        builder.setNegativeButton("Non", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

}

