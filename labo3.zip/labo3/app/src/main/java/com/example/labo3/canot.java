package com.example.labo3;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.TaskStackBuilder;

public class canot extends AppCompatActivity {

    private int c ;
    @Override

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.canot);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.canot, null);

        Button btnPlus = dialogView.findViewById(R.id.btnPlus);
        Button btnMoins = dialogView.findViewById(R.id.btnMoins);
        TextView textViewCompteur = dialogView.findViewById(R.id.textViewCompteur);

        dialogBuilder.setView(dialogView)
                .setTitle("Canot")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                })
                .setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });

        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();

        btnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c++;
                textViewCompteur.setText(String.valueOf(c));
            }
        });

        btnMoins.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (c > 0) {
                    c--;
                    textViewCompteur.setText(String.valueOf(c));
                }
            }
        });
    }
}
