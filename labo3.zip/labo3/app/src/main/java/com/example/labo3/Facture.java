package com.example.labo3;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class Facture extends AppCompatActivity {

    private int c  ;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.facture);


        afficherFacture(this);
    }

    public  void afficherFacture(Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        LayoutInflater inflater = LayoutInflater.from(context);
        View dialogView = inflater.inflate(R.layout.facture, null);

        double montantTotal = calculerMontantTotal();
        double fraisSejour = FraisSejour(Calendar.getInstance(), Calendar.getInstance());
        TextView textViewMontantTotal = dialogView.findViewById(R.id.textViewTotalAmount);
        textViewMontantTotal.setText(String.format("Montant à payer : $%.2f", montantTotal + fraisSejour));


        builder.setView(dialogView)
                .setTitle("Facture")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                })
                .setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private double calculerMontantTotal() {
        double montantTotal = 0.0;
        double montantEquitation = calculerMontantEquitation();
        double montantCanot = calculerMontantCanot();
        double montantEscalade = calculerMontantEscalade();
        montantTotal = (montantEquitation + montantCanot + montantEscalade )*c;
        return montantTotal;
    }

    private  double calculerMontantEquitation() {
        double montantTotalEquitation = 0.0;
        RadioButton radioButtonParcours1 = findViewById(R.id.radioButtonParcours1);
        RadioButton radioButtonParcours2 = findViewById(R.id.radioButtonParcours2);
        RadioButton radioButtonweek = findViewById(R.id.radioButtonWeek);
        RadioButton radioButtonweekend = findViewById(R.id.radioButtonWeekend);

        if (radioButtonParcours1.isChecked()) {
            if (radioButtonweek.isChecked()) {
                montantTotalEquitation += 15.25 * c;
            } else if (radioButtonweekend.isChecked()) {
                montantTotalEquitation += 18.25 * c;
            }
        } else if (radioButtonParcours2.isChecked()) {
            if (radioButtonweek.isChecked()) {
                montantTotalEquitation += 22.75 * c ;
            } else if (radioButtonweekend.isChecked()) {
                montantTotalEquitation += 25.00 * c;
            }
        }

        return montantTotalEquitation;
    }

    private  double calculerMontantCanot() {
        RadioButton radioSemaine = findViewById(R.id.radioSemaine);
        boolean semaineSelected = radioSemaine.isChecked();

        double montant;
        if (semaineSelected) {
            montant = 22.35 * c;
        } else {
            montant = 29.55 * c;
        }
        return montant;
    }

    private double calculerMontantEscalade() {
        RadioButton radioDuree = findViewById(R.id.reserver);
        double montant = 0.0;

        if (radioDuree.isChecked()) {
            montant = 10.0 * c;
        }
        return montant;

    }
    private double FraisSejour(Calendar dateDepart, Calendar dateArrivee) {
        double fraisTotalSejour = 0.0;


        Calendar dateMai = Calendar.getInstance();
        dateMai.set(Calendar.MONTH, Calendar.MAY);
        dateMai.set(Calendar.DAY_OF_MONTH, 31);

        Calendar dateJuin = Calendar.getInstance();
        dateJuin.set(Calendar.MONTH, Calendar.JUNE);
        dateJuin.set(Calendar.DAY_OF_MONTH, 1);

        Calendar dateAout = Calendar.getInstance();
        dateAout.set(Calendar.MONTH, Calendar.AUGUST);
        dateAout.set(Calendar.DAY_OF_MONTH, 31);


        int joursAvantJuin = differenceEnJours(dateDepart, dateMai);
        int joursEntreJuinAout = differenceEnJours(dateJuin, dateAout);
        int joursApresAout = differenceEnJours(dateArrivee, dateAout);


        double fraisAvantJuin = 0.0;
        double fraisEntreJuinAout = 0.0;
        double fraisApresAout = 0.0;

        if (joursAvantJuin > 0) {
            fraisAvantJuin = 18.90 * joursAvantJuin;
        }

        if (joursEntreJuinAout > 0) {
            fraisEntreJuinAout = 23.25 * joursEntreJuinAout;
        }

        if (joursApresAout > 0) {
            fraisApresAout = 20.25 * joursApresAout;
        }

        // Calcul du total
        fraisTotalSejour = fraisAvantJuin + fraisEntreJuinAout + fraisApresAout;

        return fraisTotalSejour;
    }
    private int differenceEnJours(Calendar dateDebut, Calendar dateFin) {
        long differenceMillis = dateFin.getTimeInMillis() - dateDebut.getTimeInMillis();
        return (int) (differenceMillis / (24 * 60 * 60 * 1000));
    }
}
