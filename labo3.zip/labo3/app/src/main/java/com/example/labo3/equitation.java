package com.example.labo3;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class equitation extends AppCompatActivity {
private int c = 0 ;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.equitation);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.equitation, null);

        Button btnPlus = dialogView.findViewById(R.id.btnPlus);
        Button btnMoins = dialogView.findViewById(R.id.btnMoins);
        TextView textViewCompteur = dialogView.findViewById(R.id.textViewCompteur);

        builder.setView(dialogView)
                .setTitle("Équitation")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                })
                .setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });

        btnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c++;
                textViewCompteur.setText(String.valueOf(c));
            }
        });
        btnMoins.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (c > 0) {
                    c--;
                    textViewCompteur.setText(String.valueOf(c));
                }
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }



}

